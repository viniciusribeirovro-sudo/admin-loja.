# Admin Loja — versão 2

## Como atualizar (nesta ordem)
1. **Regras do Firebase primeiro:** Firestore Database > aba Regras > apague tudo > cole o conteúdo de `firestore.rules` > Publicar.
   (As regras novas continuam aceitando o app antigo, então pode publicar antes de instalar.)
2. **GitHub:** envie o `admin-loja.zip` de novo (mesmo nome, substitui o anterior).
   O arquivo `.github/workflows/gerar-apk.yml` que você já criou continua igual.
3. Actions > Gerar APK > Run workflow > baixe o APK.
4. **Primeira vez só:** desinstale o app antigo antes de instalar este (a chave de assinatura mudou).
   Os dados ficam no Firebase; basta entrar de novo. A partir daqui, os próximos APKs instalam por cima.

## Regras de estoque
- O estoque baixa quando o pedido é **criado** (vale como reserva) e volta se o pedido for cancelado ou excluído.
- Separar e entregar **não mexem** no estoque (sem baixa dupla).
- Editar um pedido ajusta só a diferença de quantidade.
- Cada movimentação fica no histórico do produto (venda, cancelamento, entrada, ajuste).

## Limites conhecidos
- Máximo de 16 produtos diferentes por pedido (limite das regras do Firestore para gravações em lote).
- Se dois celulares vendem a última unidade ao mesmo tempo, o servidor recusa o segundo pedido e o app avisa.
