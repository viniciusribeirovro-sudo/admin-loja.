// Prepara o APK "casca": lê o endereço do app (url-do-app.txt) e grava a configuração do Capacitor.
const fs = require("fs"), path = require("path");
const achar = ["url-do-app.txt", "../url-do-app.txt", "../../url-do-app.txt"].map(p => path.resolve(p)).find(p => fs.existsSync(p));
if (!achar) { console.error("ERRO: crie o arquivo url-do-app.txt na raiz do repositório com o endereço do app (https://...)"); process.exit(1); }
const url = fs.readFileSync(achar, "utf8").replace(/\s+/g, "").replace(/\/+$/, "");
if (!/^https:\/\/[^/]+/.test(url)) { console.error("ERRO: o endereço em url-do-app.txt precisa começar com https://  (encontrei: " + url + ")"); process.exit(1); }
if (!fs.existsSync("www")) { console.error("ERRO: a pasta www não foi encontrada ao lado do package.json"); process.exit(1); }
fs.mkdirSync("dist", { recursive: true });
for (const f of fs.readdirSync("www")) fs.copyFileSync(path.join("www", f), path.join("dist", f));
fs.writeFileSync(path.join("dist", "error.html"), fs.readFileSync(path.join("dist", "error.html"), "utf8").split("__APP_URL__").join(url));
fs.writeFileSync("capacitor.config.json", JSON.stringify({ appId: "br.com.anele.adminloja", appName: "Admin Loja", webDir: "dist", server: { url, androidScheme: "https", allowNavigation: ["*"], errorPath: "error.html" } }));
console.log("App vai carregar: " + url + "  (lido de " + achar + ")");
