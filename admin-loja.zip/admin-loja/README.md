# Admin Loja (APK + Firebase)

## 1. Firebase (grátis, plano Spark)
1. console.firebase.google.com > **Adicionar projeto**.
2. **Criação > Authentication > Vamos começar > E-mail/senha > Ativar**.
3. **Criação > Firestore Database > Criar banco de dados** (região `southamerica-east1`, modo produção).
4. Aba **Regras** do Firestore: apague tudo, cole o conteúdo de `firestore.rules` e clique **Publicar**.
5. **Configurações do projeto (engrenagem) > Seus apps > ícone `</>` (Web)** > registre o app e copie o `firebaseConfig`.
6. Cole os valores em `src/firebase-config.js`.

## 2. Gerar o APK (sem instalar nada no PC)
1. No GitHub, envie o `admin-loja.zip` inteiro (sem descompactar) para o repositório.
2. Crie o arquivo `.github/workflows/gerar-apk.yml` (texto enviado na conversa).
3. Aba **Actions > Gerar APK > Run workflow**. Leva uns 5 a 10 minutos.
4. Ao terminar, abra a execução e baixe **admin-loja-apk** (zip com o `app-debug.apk`).

## 3. Instalar nos 3 celulares
Envie o `app-debug.apk` (WhatsApp, Drive, cabo) e permita "instalar apps desconhecidos".
No **primeiro** celular, toque em **Criar administrador**. Depois, em **Usuários**, cadastre os demais.

## Observações
- Offline: o app continua funcionando e sincroniza quando a internet volta. Se dois celulares venderem a última unidade offline, o servidor recusa o segundo pedido e o app avisa.
- Excluir um usuário bloqueia o acesso na hora, mas a conta continua listada em Authentication no Firebase (pode apagar lá, se quiser).
- Backup/Restaurar aceitam também o backup gerado pela versão antiga (só produtos, clientes, pedidos e caixa; usuários são recriados na tela Usuários).
