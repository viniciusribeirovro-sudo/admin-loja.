# Admin Loja — versão 3

## Como atualizar (nesta ordem)
1. **Regras do Firebase:** Firestore Database > Regras > apague tudo > cole o `firestore.rules` > Publicar.
   (As regras novas incluem categorias, custos e preferências; o app antigo continua funcionando com elas.)
2. **GitHub:** envie o `admin-loja.zip` de novo (mesmo nome) e rode Actions > Gerar APK.
3. Instale o APK por cima do atual (a assinatura é a mesma da versão 2).
4. Entre como administrador: Configurações (⚙) > Categorias de produtos > "Ver e organizar" para ligar os produtos antigos às categorias.

## Onde fica cada coisa
- Tela inicial: indicadores + gráfico. Engrenagem (⚙) no canto superior direito abre a central de configurações.
- Configurações: tamanho do texto (todos), Relatórios, Categorias, Catálogo (gestão), Usuários, Permissões, Histórico, Backup (admin), Sair.
- Produto: custo é guardado em coleção separada (`custos`), só admin/gerente leem. Nunca vai para o WhatsApp.
- Pedido: data de entrega opcional, acréscimos (+ descrição), cliente "Cliente não identificado" (cg).

## Regras de estoque
- O estoque baixa quando o pedido é criado e volta se for cancelado/excluído. Separar e entregar não mexem no estoque.
- Editar um pedido ajusta só a diferença. Acréscimos e descontos nunca mexem no estoque.

## Limites conhecidos
- Máximo de 16 produtos diferentes por pedido (limite das regras do Firestore para gravações em lote).
- Se dois celulares vendem a última unidade ao mesmo tempo, o servidor recusa o segundo pedido e o app avisa.
