# Admin Loja — casca do APK (versão 5)

Este APK só "abre" o aplicativo hospedado no Netlify. O código do app não fica mais dentro do APK:
as atualizações chegam pela internet (aviso "Nova versão disponível" dentro do app).

## Para gerar o APK
1. Crie na raiz do repositório o arquivo `url-do-app.txt` com o endereço do app, por exemplo:
   `https://anele-app.netlify.app`
2. Envie este `admin-loja.zip` (mesmo nome) e rode Actions > Gerar APK.
3. Baixe o APK, instale uma vez em cada celular. Depois disso, as atualizações do app não precisam de novo APK.

O APK só precisa ser refeito se mudar algo do Android em si (ícone, permissões, plugins).

## Assinatura (versão 6)
Pacote: `br.com.anele.adminloja`. O APK sai assinado com a chave de release (alias `adminloja`).
No GitHub: Settings > Secrets > Actions, crie `KEYSTORE_B64` (a chave em base64) e `KEYSTORE_PASSWORD`.
O APK final é `admin-loja-assinado.apk`. Guarde a chave fora do repositório: se perder, não dá para atualizar o app.
