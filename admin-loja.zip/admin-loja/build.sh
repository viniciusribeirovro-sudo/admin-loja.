set -e
cd "$(dirname "$0")"
# Lê url-do-app.txt (raiz do repositório) e gera a configuração do Capacitor
node prep.js
if [ "$DRY" = "1" ]; then cat capacitor.config.json; exit 0; fi
npm install
npx cap add android
M=android/app/src/main/AndroidManifest.xml
grep -q "permission.CAMERA" $M || sed -i 's#<application#<uses-permission android:name="android.permission.CAMERA" /><application#' $M
cp -r resources/android-res/. android/app/src/main/res/
npx cap sync android
yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --licenses > /dev/null || true
# versionCode crescente a cada build
sed -i "s/versionCode 1$/versionCode $(( $(date +%s) / 60 ))/" android/app/build.gradle || true
grep -n "versionCode\|versionName" android/app/build.gradle || true
cd android && chmod +x gradlew && ./gradlew assembleRelease
# assina com a chave de release (vem dos Secrets do GitHub, nunca fica no repositório)
: "${KEYSTORE_B64:?defina o secret KEYSTORE_B64}" ; : "${KEYSTORE_PASSWORD:?defina o secret KEYSTORE_PASSWORD}"
echo "$KEYSTORE_B64" | base64 -d > "$HOME/release.jks"
BT=$(ls -d "$ANDROID_HOME"/build-tools/* | sort -V | tail -1)
UNSIGNED=$(ls app/build/outputs/apk/release/*.apk | head -1)
"$BT/apksigner" sign --ks "$HOME/release.jks" --ks-key-alias adminloja --ks-pass env:KEYSTORE_PASSWORD --out app/build/outputs/apk/release/admin-loja-assinado.apk "$UNSIGNED"
"$BT/apksigner" verify --print-certs app/build/outputs/apk/release/admin-loja-assinado.apk
rm -f "$HOME/release.jks"
