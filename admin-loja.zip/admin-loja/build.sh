set -e
cd "$(dirname "$0")"
npm install
npm run build
npx cap add android
M=android/app/src/main/AndroidManifest.xml
grep -q "permission.CAMERA" $M || sed -i 's#<application#<uses-permission android:name="android.permission.CAMERA" /><application#' $M
cp -r resources/android-res/. android/app/src/main/res/
npx cap sync android
yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --licenses > /dev/null || true
cd android && chmod +x gradlew && ./gradlew assembleDebug
