set -e
cd "$(dirname "$0")"
# Lê url-do-app.txt (raiz do repositório) e gera a configuração do Capacitor
node prep.js
if [ "$DRY" = "1" ]; then cat capacitor.config.json; exit 0; fi
npm install
npx cap add android
M=android/app/src/main/AndroidManifest.xml
grep -q "permission.CAMERA" $M || sed -i 's#<application#<uses-permission android:name="android.permission.CAMERA" /><application#' $M
cp -r resources/android-res/. android/app/src/main/res/
npx cap sync android
yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --licenses > /dev/null || true
# assinatura fixa: o APK novo instala por cima do antigo
mkdir -p ~/.android && cp debug.keystore ~/.android/debug.keystore
# versionCode crescente a cada build
sed -i "s/versionCode 1$/versionCode $(( $(date +%s) / 60 ))/" android/app/build.gradle || true
grep -n "versionCode\|versionName" android/app/build.gradle || true
cd android && chmod +x gradlew && ./gradlew assembleDebug
