set -e
cd "$(dirname "$0")"
# O endereço do app (Netlify) fica no arquivo url-do-app.txt, na raiz do repositório.
URLF="../url-do-app.txt"
if [ ! -f "$URLF" ]; then echo "ERRO: crie o arquivo url-do-app.txt na raiz do repositório com o endereço do app (https://...)"; exit 1; fi
APP_URL=$(tr -d ' \r\n' < "$URLF" | sed 's#/*$##')
case "$APP_URL" in https://*) ;; *) echo "ERRO: url-do-app.txt precisa começar com https://"; exit 1;; esac
mkdir -p dist && cp www/* dist/
cat > capacitor.config.json <<JSON
{"appId":"com.adminloja.app","appName":"Admin Loja","webDir":"dist","server":{"url":"$APP_URL","androidScheme":"https","errorPath":"error.html"}}
JSON
echo "App vai carregar: $APP_URL"
if [ "$DRY" = "1" ]; then cat capacitor.config.json; exit 0; fi
npm install
npx cap add android
M=android/app/src/main/AndroidManifest.xml
grep -q "permission.CAMERA" $M || sed -i 's#<application#<uses-permission android:name="android.permission.CAMERA" /><application#' $M
cp -r resources/android-res/. android/app/src/main/res/
npx cap sync android
yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --licenses > /dev/null || true
# assinatura fixa: o APK novo instala por cima do antigo
mkdir -p ~/.android && cp debug.keystore ~/.android/debug.keystore
# versionCode crescente a cada build
sed -i "s/versionCode 1$/versionCode $(( $(date +%s) / 60 ))/" android/app/build.gradle || true
grep -n "versionCode\|versionName" android/app/build.gradle || true
cd android && chmod +x gradlew && ./gradlew assembleDebug
