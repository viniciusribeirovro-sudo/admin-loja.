import {initializeApp} from "firebase/app";
import * as FS from "firebase/firestore";
import * as AU from "firebase/auth";
import {Capacitor} from "@capacitor/core";
import {Share} from "@capacitor/share";
import {Filesystem,Directory} from "@capacitor/filesystem";
import {Browser} from "@capacitor/browser";
import {App} from "@capacitor/app";
import {firebaseConfig} from "./firebase-config.js";
var K="adminloja-v1",DB,me=null,tab="home",flt="todos",Q="",tmp=[],tt,V={},L={},A={},ST=["pendente","pago","entregue","cancelado"],
T={home:"Início",ord:"Pedidos",prod:"Produtos",cust:"Clientes",cash:"Financeiro",users:"Usuários"},
IC={home:'<path d="M3 11l9-8 9 8v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',list:'<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M9 8h6M9 12h6M9 16h4"/>',box:'<path d="M12 3l8 4.5v9L12 21l-8-4.5v-9z"/><path d="M4 7.5L12 12l8-4.5M12 12v9"/>',users:'<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.5 3-6 6.5-6s6.5 2.5 6.5 6"/><path d="M16 4.5a3.5 3.5 0 0 1 0 7M18 14.5c2 .7 3.5 2.6 3.5 5.5"/>',wallet:'<rect x="3" y="6" width="18" height="14" rx="3"/><path d="M3 10h18M16 15h2"/>',chat:'<path d="M12 3c5 0 9 3.4 9 7.7S17 18.4 12 18.4c-1 0-2-.1-2.9-.4L4 20l1.2-3.6C3.8 15.2 3 13.5 3 10.7 3 6.4 7 3 12 3z"/>',back:'<path d="M15 5l-7 7 7 7"/>',plus:'<path d="M12 5v14M5 12h14"/>',share:'<circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="6" r="2.5"/><circle cx="18" cy="18" r="2.5"/><path d="M8.2 10.8l7.6-3.6M8.2 13.2l7.6 3.6"/>',pdf:'<path d="M6 3h8l5 5v13H6z"/><path d="M12 11v6M9 14l3 3 3-3"/>',search:'<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>'};
function ic(n){return'<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">'+IC[n]+'</svg>'}
function $(i){return document.getElementById(i)}
var app=initializeApp(firebaseConfig),auth=AU.getAuth(app),fdb=FS.initializeFirestore(app,{localCache:FS.persistentLocalCache({})}),EM="@adminloja.app",unsubs=[],loaded={},need=[],BUSY=false,sec=null,
SRT={prods:nm,cust:nm,users:nm,ord:function(a,b){return a.id-b.id},cash:function(a,b){return(a.ts||0)-(b.ts||0)}};
function nm(a,b){return String(a.n||"").localeCompare(String(b.n||""))}
function load(){DB={users:[],prods:[],cust:[],ord:[],cash:[]}}
function dref(n,i){return FS.doc(fdb,n,String(i))}
function cashId(i){return"o"+i}
function cashOf(i,o){return{ts:uid(),tp:"entrada",v:tot(o),d:"Pedido #"+String(i).slice(-4),cat:"Vendas",dt:hoje(),oid:String(i)}}
function cleanU(s){s=String(s||"").trim().toLowerCase();return/^[a-z0-9._-]{2,30}$/.test(s)?s:""}
function mkEm(){return"u"+uid()+EM}
function ready(){return need.every(function(n){return loaded[n]})}
function fail(e){console.error(e);var c=e&&e.code||"";toast(c=="permission-denied"?"Recusado: sem permissão ou estoque insuficiente.":c=="auth/requires-recent-login"?"Saia e entre de novo para trocar a senha.":c=="auth/weak-password"?"A senha precisa ter ao menos 6 caracteres.":c=="auth/network-request-failed"||c=="unavailable"?"Sem conexão. Tente de novo.":"Não foi possível salvar.")}
function kick(m){toast(m);AU.signOut(auth)}
function refresh(){if(!me||!ready())return;var l=$("lst");if(l&&L[tab])l.innerHTML=L[tab]();else R()}
function unsub(){unsubs.forEach(function(f){f()});unsubs=[];loaded={};need=[];load()}
function sub(n){unsubs.push(FS.onSnapshot(FS.collection(fdb,n),function(s){DB[n]=s.docs.map(function(d){var o=d.data();o.id=d.id;return o}).sort(SRT[n]);loaded[n]=1;refresh()},function(e){if(e&&e.code=="permission-denied")kick("Sem permissão de acesso.");else console.error(e)}))}
function subscribe(){unsub();need=["prods","cust","ord"];if(G())need.push("cash");if(me.r=="admin")need.push("users");need.forEach(sub);
unsubs.push(FS.onSnapshot(dref("users",me.id),function(s){if(!s.exists()){kick("Seu acesso foi removido.");return}var o=s.data();me.n=o.n;if(o.r!=me.r){me.r=o.r;if(tab=="cash"&&!G()||tab=="users"&&me.r!="admin")tab="home";subscribe();R()}},function(){}))}
async function enter(u){try{var s=await FS.getDoc(dref("users",u.uid));if(!s.exists()){await AU.signOut(auth);toast("Esse usuário não tem acesso ao app.");return}
me=s.data();me.id=u.uid;tab="home";subscribe();R()}catch(e){console.error(e);toast("Não foi possível entrar. Verifique a conexão.");AU.signOut(auth)}}
function mkAuth(em,p){var a=AU.getAuth(sec||(sec=initializeApp(firebaseConfig,"sec")));return AU.createUserWithEmailAndPassword(a,em,p).then(function(c){return AU.signOut(a).then(function(){return c.user.uid})})}
function doLogin(){var u=cleanU($("lu").value),p=$("lp").value;if(!u||!p)return toast("Informe usuário e senha.");$("lb").disabled=true;
FS.getDoc(dref("logins",u)).then(function(s){if(!s.exists())throw{code:"nouser"};return AU.signInWithEmailAndPassword(auth,s.data().em,p)}).catch(function(e){var b=$("lb"),c=e&&e.code||"";if(b)b.disabled=false;toast(c=="unavailable"||c=="auth/network-request-failed"?"Sem conexão com a internet.":c=="auth/too-many-requests"?"Muitas tentativas. Aguarde um pouco.":"Usuário ou senha incorretos.")})}
function toast(t){var e=$("ts");e.textContent=t;e.className="on";clearTimeout(tt);tt=setTimeout(function(){e.className=""},2800)}
window.alert=toast;
function esc(s){return String(s==null?"":s).replace(/[&<>"]/g,function(c){return{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]})}
function brl(n){return(n||0).toLocaleString("pt-BR",{style:"currency",currency:"BRL"})}
function uid(){return Date.now()*10+Math.floor(Math.random()*10)}
function hoje(){return new Date().toLocaleString("pt-BR",{dateStyle:"short",timeStyle:"short"}).replace(",","")}
function cap(s){return s.charAt(0).toUpperCase()+s.slice(1)}
function g(a,i){return a.filter(function(x){return x.id==i})[0]}
function G(){return me.r!="vendedor"}
function tot(o){return o.items.reduce(function(s,i){return s+i.q*i.pr},0)-(o.disc||0)}
function cs(){var e=0,s=0;DB.cash.forEach(function(c){c.tp=="entrada"?e+=c.v:s+=c.v});return[e,s]}
function empty(t){return'<p class="m" style="text-align:center;padding:24px 0">'+t+'</p>'}
function sb(p){return'<div class="sb">'+ic("search")+'<input data-q="1" placeholder="'+p+'" value="'+esc(Q)+'"></div>'}
function wa(t,tel){var n=String(tel||"").replace(/\D/g,"");if(n&&n.length<=11)n="55"+n;var u="https://wa.me/"+n+"?text="+encodeURIComponent(t),w=null;if(Capacitor.isNativePlatform()){Browser.open({url:u}).catch(function(){SP(t,u)});return}try{w=window.open(u,"_blank")}catch(e){}if(!w)SP(t,u)}
function SP(t,u){$("sh").innerHTML='<div class="sc"><b class="h" style="font-size:1.2rem">Compartilhar</b><p class="m">Toque em Abrir no WhatsApp ou copie o texto.</p><textarea id="bt" rows="6" readonly>'+esc(t)+'</textarea><a class="bp ac" href="'+esc(u)+'" target="_blank" rel="noopener" style="text-decoration:none">Abrir no WhatsApp</a>'+(navigator.share?'<button class="bp ol" data-a="sn">Compartilhar…</button>':'')+'<button class="bp ol" data-a="cp">Copiar texto</button><button class="bp ol" data-a="x2">Fechar</button></div>';$("sh").hidden=false}
function cl(s){return String(s).replace(/\u00a0/g," ").replace(/[\u2013\u2014\u2212]/g,"-").replace(/[^\x20-\x7e\xa1-\xff]/g,"?")}
function pR(s,n){s=cl(s).slice(0,n);return s+" ".repeat(n-s.length)}
function pL(s,n){s=cl(s).slice(0,n);return" ".repeat(n-s.length)+s}
function money(n){return cl(brl(n))}
function wrapL(s,n){var r=[];s=cl(s);while(s.length>n){var k=s.lastIndexOf(" ",n);if(k<1)k=n;r.push(s.slice(0,k));s=s.slice(k).replace(/^ /,"")}r.push(s);return r}
function pdf(lines){var per=56,pg=[],i;for(i=0;i<lines.length;i+=per)pg.push(lines.slice(i,i+per));if(!pg.length)pg.push([""]);
var ob=["","<< /Type /Catalog /Pages 2 0 R >>","<< /Type /Pages /Kids ["+pg.map(function(_,k){return(5+2*k)+" 0 R"}).join(" ")+"] /Count "+pg.length+" >>","<< /Type /Font /Subtype /Type1 /BaseFont /Courier /Encoding /WinAnsiEncoding >>"];
pg.forEach(function(l,k){var s="BT /F1 10 Tf 13 TL 40 800 Td\n"+l.map(function(x){return"("+cl(x).replace(/([\\()])/g,"\\$1")+") Tj T*"}).join("\n")+"\nET";
ob[4+2*k]="<< /Length "+s.length+" >>\nstream\n"+s+"\nendstream";
ob[5+2*k]="<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 3 0 R >> >> /Contents "+(4+2*k)+" 0 R >>"});
var o="%PDF-1.4\n",off=[];for(i=1;i<ob.length;i++){off[i]=o.length;o+=i+" 0 obj\n"+ob[i]+"\nendobj\n"}
var x=o.length;o+="xref\n0 "+ob.length+"\n0000000000 65535 f \n";for(i=1;i<ob.length;i++)o+=("0000000000"+off[i]).slice(-10)+" 00000 n \n";
o+="trailer\n<< /Size "+ob.length+" /Root 1 0 R >>\nstartxref\n"+x+"\n%%EOF";
var u=new Uint8Array(o.length);for(i=0;i<o.length;i++)u[i]=o.charCodeAt(i)&255;return u}
async function dl(name,b){
if(Capacitor.isNativePlatform()){try{var s="",k;for(k=0;k<b.length;k+=8192)s+=String.fromCharCode.apply(null,b.subarray(k,k+8192));var f=await Filesystem.writeFile({path:name,data:btoa(s),directory:Directory.Cache});await Share.share({title:name,url:f.uri,dialogTitle:"Compartilhar PDF"})}catch(e){if(!/cancel/i.test(String(e&&e.message||e)))toast("Não foi possível gerar o PDF.")}return}
try{var u=URL.createObjectURL(new Blob([b],{type:"application/pdf"})),a=document.createElement("a");a.href=u;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(function(){URL.revokeObjectURL(u)},4000);toast("PDF gerado.")}catch(e){toast("Não foi possível gerar o PDF neste aparelho.")}}
function X(){$("md").hidden=true;$("md").innerHTML=""}
var PH="",PB=0;
function pic(f,cb,er){var r=new FileReader(),bad=function(){er("Não consegui ler essa imagem. Use uma foto JPG ou PNG.")};r.onerror=bad;r.onload=function(){var im=new Image();im.onerror=bad;im.onload=function(){var s=Math.min(1,320/Math.max(im.width,im.height)),c=document.createElement("canvas");c.width=Math.max(1,Math.round(im.width*s));c.height=Math.max(1,Math.round(im.height*s));c.getContext("2d").drawImage(im,0,0,c.width,c.height);cb(c.toDataURL("image/jpeg",.75))};im.src=r.result};r.readAsDataURL(f)}
function phv(){var w=$("pvw");if(!w)return;w.innerHTML=PH?'<img class="av" alt="" src="'+PH+'">':'<div class="av">'+ic("box")+'</div>';$("pm").textContent=PH?"Foto selecionada":"Sem foto"}
function PHload(t){var f=t.files[0];if(!f)return;PB=1;toast("Processando foto…");pic(f,function(u){PH=u;PB=0;phv();toast("Foto pronta.")},function(m){PB=0;toast(m)})}
function P(t,sub,body,foot){$("md").innerHTML='<div class="pg"><div class="ph"><button class="ib" data-a="x" aria-label="Voltar">'+ic("back")+'</button><div><div class="pt">'+t+'</div>'+(sub?'<div class="m">'+sub+'</div>':'')+'</div></div><div class="pb">'+body+'</div>'+(foot?'<div class="pf">'+foot+'</div>':'')+'</div>';$("md").hidden=false}
function F(t,fs,v,cb,del){v=v||{};
P(t,"",fs.map(function(f){var k=f[0],x=v[k]==null?"":v[k],i;
if(f[2]=="s")i='<select id="f_'+k+'">'+f[3].map(function(o){return'<option value="'+o[0]+'"'+(o[0]==x?" selected":"")+'>'+o[1]+'</option>'}).join("")+'</select>';
else if(f[2]=="t")i='<textarea id="f_'+k+'" rows="3">'+esc(x)+'</textarea>';
else if(f[2]=="f")i='<div class="c r" style="margin:8px 0 0"><div class="it"><span id="pvw"></span><span class="m" id="pm"></span></div><div class="w" style="margin:0;justify-content:flex-end"><label class="chip on" for="ph1" style="margin:0">Câmera</label><label class="chip on" for="ph2" style="margin:0">Galeria</label><button type="button" class="chip" data-a="phx">Remover</button></div></div><input class="hf" id="ph1" type="file" accept="image/*" capture="environment" data-ph="1"><input class="hf" id="ph2" type="file" accept="image/*" data-ph="1">';
else i='<input id="f_'+k+'" '+(f[2]=="n"?'type="number" step="any" inputmode="decimal" ':'')+'value="'+esc(x)+'">';
return'<label>'+f[1]+i+'</label>'}).join("")+(del?'<button class="bp ol dg" data-a="'+del[0]+'" data-i="'+del[1]+'">Excluir</button>':''),'<button class="bp" id="ok">Salvar</button>');
phv();$("ok").onclick=function(){if(PB)return toast("Aguarde a foto terminar de carregar.");var o={};fs.forEach(function(f){var e=$("f_"+f[0]);o[f[0]]=f[2]=="n"?parseFloat(e.value)||0:f[2]=="f"?PH:e.value.trim()});cb(o)}}

function R(){if(!me){login();return}if(!ready()){$("app").innerHTML='<header><h1>Admin Loja</h1></header><main><p class="m" style="text-align:center;padding:40px 0">Carregando dados…</p></main>';return}
var t=[["home","Início","home"],["ord","Pedidos","list"],["prod","Produtos","box"],["cust","Clientes","users"]];if(G())t.push(["cash","Financeiro","wallet"]);
var fb={ord:"no",prod:"np",cust:"nc2",cash:"nl",users:"nu"}[tab];if(tab!="ord"&&!G())fb=0;
$("app").innerHTML='<header><h1>'+T[tab]+(navigator.onLine?'':' <span class="m" style="font-size:.9rem">· offline</span>')+'</h1></header><main>'+V[tab]()+'</main>'+(fb?'<button class="fab" data-a="'+fb+'" aria-label="Novo">'+ic("plus")+'</button>':'')+'<nav>'+t.map(function(x){return'<button class="'+(tab==x[0]?"on":"")+'" data-a="tab" data-i="'+x[0]+'">'+ic(x[2])+'<span>'+x[1]+'</span></button>'}).join("")+'</nav>'}
function login(){$("app").innerHTML='<div class="lg"><h1>Admin Loja</h1><p class="m" style="margin-bottom:24px">Entre para continuar.</p><label>Usuário<input id="lu" autocapitalize="none" autocomplete="username"></label><label>Senha<input id="lp" type="password" autocomplete="current-password"></label><button class="bp" id="lb">Entrar</button><div id="fs"></div></div>';
$("lb").onclick=doLogin;$("lp").onkeydown=function(e){if(e.key=="Enter")doLogin()};
FS.getDoc(dref("meta","setup")).then(function(s){var e=$("fs");if(e&&!s.exists()&&!me)e.innerHTML='<p class="m">Nenhum administrador criado ainda.</p><button class="bp ac" data-a="su">Criar administrador</button>'}).catch(function(){})}

V.home=function(){var n=function(s){return DB.ord.filter(function(x){return x.s==s}).length},low=DB.prods.filter(function(p){return p.st<=3}).length;
return'<p class="m" style="margin:0 0 14px">Olá, '+esc(me.n)+' · '+me.r+'</p><div class="gr">'+[["Pendentes",n("pendente")],["Pagos",n("pago")],["Entregues",n("entregue")],["Estoque baixo",low]].map(function(x){return'<div class="c"><div class="m">'+x[0]+'</div><b class="big">'+x[1]+'</b></div>'}).join("")+'</div>'+
(G()?'<div class="c" style="margin-top:12px"><div class="m">Saldo do caixa</div><b class="big gn">'+brl(cs()[0]-cs()[1])+'</b></div>':'')+
'<button class="bp ol" data-a="pc">'+ic("pdf")+' Catálogo em PDF</button><button class="bp ol" data-a="wk">Catálogo no WhatsApp</button>'+(me.r=="admin"?'<button class="bp ol" data-a="bk">Backup</button><button class="bp ol" data-a="rs">Restaurar backup</button>':'')+''+(me.r=="admin"?'<button class="bp ol" data-a="tab" data-i="users">Usuários</button>':'')+'<button class="bp ol dg" data-a="out">Sair</button>'}

function oc(o){return'<div class="c tap" data-a="od" data-i="'+o.id+'"><div class="r"><div class="it"><div><b>'+esc(o.cn)+'</b><div class="m">'+o.dt+' · '+o.items.length+' item(ns)</div></div></div><div style="text-align:right"><b class="gn">'+brl(tot(o))+'</b><div style="margin-top:4px"><span class="pill st-'+o.s+'">'+o.s+'</span></div></div></div></div>'}
L.ord=function(){var q=Q.toLowerCase(),l=DB.ord.filter(function(o){return(flt=="todos"||o.s==flt)&&(!q||o.cn.toLowerCase().indexOf(q)>=0)}).reverse();return l.length?l.map(oc).join(""):empty("Nenhum pedido aqui.")}
V.ord=function(){return sb("Buscar pedido")+'<div class="tb">'+["todos"].concat(ST).map(function(s){return'<button class="chip'+(flt==s?" on":"")+'" data-a="fl" data-i="'+s+'">'+s+'</button>'}).join("")+'</div><div id="lst">'+L.ord()+'</div>'}
L.prod=function(){var q=Q.toLowerCase(),l=DB.prods.filter(function(p){return!q||p.n.toLowerCase().indexOf(q)>=0});return l.length?l.map(function(p){
return'<div class="c r'+(G()?' tap':'')+'"'+(G()?' data-a="np" data-i="'+p.id+'"':'')+'><div class="it">'+(p.img?'<img class="av" alt="" src="'+p.img+'">':'<div class="av">'+ic("box")+'</div>')+'<div><b>'+esc(p.n)+'</b><div class="m">'+brl(p.pr)+' · estoque '+p.st+(p.sku?' · '+esc(p.sku):'')+'</div></div></div><button class="cb" data-a="wp" data-i="'+p.id+'" aria-label="WhatsApp">'+ic("chat")+'</button></div>'}).join(""):empty("Nenhum produto. Toque em + para cadastrar.")}
V.prod=function(){return sb("Buscar produto")+'<div id="lst">'+L.prod()+'</div>'}
L.cust=function(){var q=Q.toLowerCase(),l=DB.cust.filter(function(c){return!q||c.n.toLowerCase().indexOf(q)>=0});return l.length?l.map(function(c){
return'<div class="c r'+(G()?' tap':'')+'"'+(G()?' data-a="nc2" data-i="'+c.id+'"':'')+'><div class="it"><div class="av">'+esc(c.n.charAt(0).toUpperCase())+'</div><div><b>'+esc(c.n)+'</b><div class="m">'+esc(c.t)+'</div></div></div>'+(c.t?'<button class="cb" data-a="wc" data-i="'+c.id+'" aria-label="WhatsApp">'+ic("chat")+'</button>':'')+'</div>'}).join(""):empty("Nenhum cliente. Toque em + para cadastrar.")}
V.cust=function(){return sb("Buscar cliente")+'<div id="lst">'+L.cust()+'</div>'}
V.cash=function(){var a=cs();return'<div class="gr3">'+[["Entradas",a[0]],["Saídas",a[1]],["Saldo",a[0]-a[1]]].map(function(x){return'<div class="c"><div class="m">'+x[0]+'</div><b class="big">'+brl(x[1])+'</b></div>'}).join("")+'</div>'+
(DB.cash.length?DB.cash.slice().reverse().map(function(c){return'<div class="c r"><div><b>'+esc(c.d)+'</b><div class="m">'+c.dt+(c.cat?' · '+esc(c.cat):'')+'</div></div><div style="text-align:right"><b class="'+(c.tp=="entrada"?"gn":"")+'">'+(c.tp=="entrada"?"+":"−")+brl(c.v)+'</b><div><button class="chip" data-a="dl" data-i="'+c.id+'" style="margin-top:4px;padding:5px 12px">Excluir</button></div></div></div>'}).join(""):empty("Nenhum lançamento."))}
V.users=function(){return DB.users.map(function(u){return'<div class="c r tap" data-a="nu" data-i="'+u.id+'"><div class="it"><div class="av">'+esc(u.n.charAt(0).toUpperCase())+'</div><div><b>'+esc(u.n)+'</b><div class="m">@'+esc(u.u)+' · '+u.r+'</div></div></div></div>'}).join("")}

A.tab=function(i){tab=i;Q="";R();scrollTo(0,0)};A.fl=function(i){flt=i;R()};A.x=X;A.x2=function(){$("sh").hidden=true;$("sh").innerHTML=""};A.out=function(){AU.signOut(auth)};
A.np=function(i){var p=i?g(DB.prods,i):{};PH=p.img||"";PB=0;F(i?"Editar produto":"Novo produto",[["n","Nome"],["pr","Preço (R$)","n"],["st","Estoque","n"],["sku","SKU"],["d","Descrição","t"],["img","Foto","f"]],p,function(o){if(!o.n)return toast("Informe o nome.");
var r={n:o.n,pr:o.pr,sku:o.sku,d:o.d},s=Math.max(0,o.st);
if(i){r.st=FS.increment(s-p.st);r.img=o.img||FS.deleteField();FS.updateDoc(dref("prods",i),r).catch(fail)}else{r.st=s;if(o.img)r.img=o.img;FS.setDoc(dref("prods",uid()),r).catch(fail)}X();R()},i?["dp",i]:0)};
A.phx=function(){PH="";phv()};
A.dp=function(i){if(confirm("Excluir este produto?")){FS.deleteDoc(dref("prods",i)).catch(fail);X();R()}};
A.wp=function(i){var p=g(DB.prods,i);wa("*"+p.n+"*\n"+brl(p.pr)+(p.d?"\n"+p.d:"")+"\nEm estoque: "+p.st)};
A.nc2=function(i){var c=i?g(DB.cust,i):{};F(i?"Editar cliente":"Novo cliente",[["n","Nome"],["t","Telefone (com DDD)"],["e","E-mail"],["a","Endereço"],["o","Observações","t"]],c,function(o){if(!o.n)return toast("Informe o nome.");
var r={n:o.n,t:o.t,e:o.e,a:o.a,o:o.o};(i?FS.updateDoc(dref("cust",i),r):FS.setDoc(dref("cust",uid()),r)).catch(fail);X();R()},i?["dc",i]:0)};
A.dc=function(i){if(confirm("Excluir este cliente?")){FS.deleteDoc(dref("cust",i)).catch(fail);X();R()}};
A.wc=function(i){wa("Olá!",g(DB.cust,i).t)};
A.nl=function(){F("Novo lançamento",[["tp","Tipo","s",[["entrada","Entrada"],["saida","Saída"]]],["v","Valor (R$)","n"],["d","Descrição"],["cat","Categoria"]],{},function(o){if(!o.d||!o.v)return toast("Informe descrição e valor.");
var id=uid();FS.setDoc(dref("cash",id),{ts:id,tp:o.tp,v:o.v,d:o.d,cat:o.cat,dt:hoje()}).catch(fail);X();R()})};
A.dl=function(i){if(confirm("Excluir este lançamento?")){FS.deleteDoc(dref("cash",i)).catch(fail);R()}};
A.su=function(){F("Criar administrador",[["n","Seu nome"],["u","Usuário (login)"],["p","Senha (mínimo 6 caracteres)"]],{},function(o){var un=cleanU(o.u);if(!o.n||!un)return toast("Informe nome e usuário (letras, números, ponto, - ou _).");if(o.p.length<6)return toast("A senha precisa ter ao menos 6 caracteres.");
BUSY=true;toast("Criando…");var em=mkEm();
AU.createUserWithEmailAndPassword(auth,em,o.p).then(function(c){var b=FS.writeBatch(fdb);b.set(dref("meta","setup"),{done:true});b.set(dref("users",c.user.uid),{n:o.n,u:un,r:"admin",em:em});b.set(dref("logins",un),{em:em});return b.commit().then(function(){BUSY=false;X();enter(c.user)})}).catch(function(e){BUSY=false;AU.signOut(auth);fail(e)})})};
A.nu=function(i){var u=i?g(DB.users,i):{};F(i?"Editar usuário":"Novo usuário",[["n","Nome"],["u","Usuário (login)"],["p","Senha"+(i?" (vazio mantém a atual)":"")],["r","Perfil","s",[["admin","Administrador"],["gerente","Gerente"],["vendedor","Vendedor"]]]],{n:u.n,u:u.u,r:u.r||"vendedor"},function(o){
var un=cleanU(o.u);if(!o.n||!un)return toast("Informe nome e usuário (letras, números, ponto, - ou _).");
if(!i&&!o.p)return toast("Informe a senha.");if(o.p&&o.p.length<6)return toast("A senha precisa ter ao menos 6 caracteres.");
if(DB.users.some(function(x){return x.u==un&&x.id!=i}))return toast("Esse usuário já existe.");
if(o.r!="admin"&&!DB.users.some(function(x){return x.id!=i&&x.r=="admin"}))return toast("Precisa existir ao menos um administrador.");
var b=FS.writeBatch(fdb),p=null,done=function(){X();R()};
if(!i||o.p&&i!=me.id){var em=mkEm();p=mkAuth(em,o.p).then(function(id){b.set(dref("users",id),{n:o.n,u:un,r:o.r,em:em});b.set(dref("logins",un),{em:em});if(i){b.delete(dref("users",i));if(un!=u.u)b.delete(dref("logins",u.u))}})}
else{b.update(dref("users",i),{n:o.n,u:un,r:o.r});if(un!=u.u){b.delete(dref("logins",u.u));b.set(dref("logins",un),{em:u.em})}if(o.p)p=AU.updatePassword(auth.currentUser,o.p)}
if(p){toast("Salvando…");p.then(function(){return b.commit()}).then(done).catch(fail)}else{b.commit().catch(fail);done()}
},i?["du",i]:0)};
A.du=function(i){var u=g(DB.users,i);if(u.id==me.id)return toast("Você não pode excluir o próprio usuário.");if(confirm("Excluir "+u.n+"?")){var b=FS.writeBatch(fdb);b.delete(dref("users",i));b.delete(dref("logins",u.u));b.commit().catch(fail);X();R()}};

A.no=function(){if(!DB.prods.length)return toast("Cadastre produtos antes de criar um pedido.");tmp=[];
P("Novo pedido","",'<label>Cliente<select id="f_c"><option value="">Cliente avulso</option>'+DB.cust.map(function(c){return'<option value="'+c.id+'">'+esc(c.n)+'</option>'}).join("")+'</select></label><label><input id="f_cn" placeholder="Ou digite o nome (avulso)"></label><div class="r" style="margin-bottom:8px"><b class="h" style="font-size:1.2rem">Itens</b><button class="chip on" data-a="ni" style="display:flex;gap:6px;align-items:center">'+ic("plus")+' item</button></div><div id="it"></div><label>Desconto (R$)<input id="f_d" type="number" step="any" inputmode="decimal" placeholder="0,00"></label><label>Observações<textarea id="f_o" rows="3" placeholder="Observações do pedido"></textarea></label><label>Status<select id="f_s">'+ST.map(function(s){return'<option value="'+s+'">'+cap(s)+'</option>'}).join("")+'</select></label>',
'<div class="r" style="margin-bottom:10px"><span class="m">Total</span><b class="big gn" id="tt">R$ 0,00</b></div><button class="bp" data-a="so">Salvar pedido</button>');ri()};
function ri(){var s=tmp.reduce(function(a,i){return a+i.q*i.pr},0),d=parseFloat($("f_d")&&$("f_d").value)||0;
$("it").innerHTML=tmp.length?tmp.map(function(i,k){return'<div class="c r" style="padding:12px"><span>'+i.q+' x '+esc(i.n)+'<div class="m">'+brl(i.q*i.pr)+'</div></span><button class="chip" data-a="rm" data-i="'+k+'">Remover</button></div>'}).join(""):'<p class="m" style="margin:0 0 16px">Nenhum item.</p>';$("tt").textContent=brl(s-d)}
A.rm=function(k){tmp.splice(k,1);ri()};
A.ni=function(){$("sh").innerHTML='<div class="sc"><b class="h" style="font-size:1.2rem">Adicionar item</b><label style="margin-top:14px">Produto<select id="f_p">'+DB.prods.map(function(p){return'<option value="'+p.id+'">'+esc(p.n)+' ('+p.st+' em estoque) · '+brl(p.pr)+'</option>'}).join("")+'</select></label><label>Quantidade<input id="f_q" type="number" min="1" value="1" inputmode="numeric"></label><button class="bp" data-a="ai">Adicionar</button><button class="bp ol" data-a="x2">Cancelar</button></div>';$("sh").hidden=false};
A.ai=function(){var p=g(DB.prods,$("f_p").value),q=parseInt($("f_q").value)||1,x=tmp.filter(function(i){return i.pid==p.id})[0],u=(x?x.q:0)+q;
if(u>p.st)return toast("Estoque insuficiente: só há "+p.st+" unidade(s).");if(x)x.q=u;else tmp.push({pid:p.id,n:p.n,q:q,pr:p.pr});A.x2();ri()};
A.so=function(){if(!tmp.length)return toast("Adicione ao menos um item.");var cid=$("f_c").value,c=cid?g(DB.cust,cid):null,cn=c?c.n:$("f_cn").value.trim();if(!cn)return toast("Escolha um cliente ou informe um nome.");
var id=uid(),s=$("f_s").value,b=FS.writeBatch(fdb),o={cid:cid,cn:cn,items:tmp,disc:parseFloat($("f_d").value)||0,obs:$("f_o").value,s:s,dt:hoje()};
if(s!="cancelado")tmp.forEach(function(i){b.update(dref("prods",i.pid),{st:FS.increment(-i.q)})});
b.set(dref("ord",id),o);if(s=="pago"||s=="entregue")b.set(dref("cash",cashId(id)),cashOf(id,o));
b.commit().catch(fail);tmp=[];X();flt="todos";R()};
function setS(i,v){var o=g(DB.ord,i),old=o.s;if(old==v)return;
if(old=="cancelado"&&o.items.some(function(x){var p=g(DB.prods,x.pid);return p&&p.st<x.q}))return toast("Estoque insuficiente para reativar este pedido.");
var b=FS.writeBatch(fdb),st=function(x,n){if(g(DB.prods,x.pid))b.update(dref("prods",x.pid),{st:FS.increment(n)})};
if(v=="cancelado")o.items.forEach(function(x){st(x,x.q)});
if(old=="cancelado")o.items.forEach(function(x){st(x,-x.q)});
b.update(dref("ord",i),{s:v});
if(v=="pago"||v=="entregue")b.set(dref("cash",cashId(i)),cashOf(i,o));else b.delete(dref("cash",cashId(i)));
o.s=v;b.commit().catch(fail)}
A.ss=function(i,v){setS(i,v);R();A.od(i)};
A.od=function(i){var o=g(DB.ord,i);if(!o)return;
P(esc(o.cn),o.dt,(G()?'<select class="pill st-'+o.s+'" data-c="ss" data-i="'+o.id+'">'+ST.map(function(s){return'<option value="'+s+'"'+(s==o.s?" selected":"")+'>'+cap(s)+'</option>'}).join("")+'</select>':'<span class="pill st-'+o.s+'">'+o.s+'</span>')+
'<div class="c" style="margin-top:16px"><b class="h" style="font-size:1.1rem">Itens</b>'+o.items.map(function(x){return'<div class="r" style="margin-top:12px"><span>'+x.q+' x '+esc(x.n)+'</span><span>'+brl(x.q*x.pr)+'</span></div>'}).join("")+(o.disc?'<div class="r m" style="margin-top:12px"><span>Desconto</span><span>−'+brl(o.disc)+'</span></div>':'')+'<hr><div class="r"><b>Total</b><b class="big gn">'+brl(tot(o))+'</b></div></div>'+(o.obs?'<p class="m">'+esc(o.obs)+'</p>':'')+
'<button class="bp ac" data-a="wo" data-i="'+o.id+'">'+ic("share")+' Compartilhar no WhatsApp</button><button class="bp ol" data-a="po" data-i="'+o.id+'">'+ic("pdf")+' Gerar PDF</button>'+(G()?'<button class="bp ol dg" data-a="do" data-i="'+o.id+'">Excluir pedido</button>':''))};
A.do=function(i){var o=g(DB.ord,i);if(!confirm("Excluir este pedido?"))return;var b=FS.writeBatch(fdb);
if(o.s!="cancelado")o.items.forEach(function(x){if(g(DB.prods,x.pid))b.update(dref("prods",x.pid),{st:FS.increment(x.q)})});
b.delete(dref("cash",cashId(i)));b.delete(dref("ord",i));b.commit().catch(fail);X();R()};
A.wo=function(i){var o=g(DB.ord,i),c=o.cid?g(DB.cust,o.cid):null;
wa("*Pedido #"+String(o.id).slice(-4)+"*\nCliente: "+o.cn+"\n"+o.items.map(function(x){return"- "+x.q+"x "+x.n+" — "+brl(x.q*x.pr)}).join("\n")+(o.disc?"\nDesconto: "+brl(o.disc):"")+"\n*Total: "+brl(tot(o))+"*\nStatus: "+o.s,c&&c.t)};
A.po=function(i){var o=g(DB.ord,i),n=String(o.id).slice(-4),R=["PEDIDO #"+n,"","Cliente: "+o.cn,"Data: "+o.dt,"Status: "+o.s,"",pR("Item",40)+pL("Qtd",5)+pL("Preço",14)+pL("Subtotal",16),"-".repeat(75)];
o.items.forEach(function(x){R.push(pR(x.n,40)+pL(x.q,5)+pL(money(x.pr),14)+pL(money(x.q*x.pr),16))});
R.push("-".repeat(75));if(o.disc)R.push(pL("Desconto: -"+money(o.disc),75));R.push(pL("TOTAL: "+money(tot(o)),75));if(o.obs){R.push("");wrapL("Obs.: "+o.obs,75).forEach(function(l){R.push(l)})}
dl("pedido-"+n+".pdf",pdf(R))};
A.pc=function(){if(!DB.prods.length)return toast("Cadastre produtos primeiro.");var R=["CATÁLOGO DE PRODUTOS","Gerado em "+hoje(),"",pR("Produto",44)+pR("SKU",12)+pL("Preço",12)+pL("Estoque",8),"-".repeat(76)];
DB.prods.forEach(function(p){R.push(pR(p.n,43)+" "+pR(p.sku||"",12)+pL(money(p.pr),12)+pL(p.st,8))});dl("catalogo.pdf",pdf(R))};
A.bk=function(){P("Backup","",'<p class="m">Copie este texto e guarde em local seguro (notas, e-mail ou nuvem). Para restaurar, use Restaurar backup.</p><textarea id="bt" rows="10" readonly>'+esc(JSON.stringify({prods:DB.prods,cust:DB.cust,ord:DB.ord,cash:DB.cash}))+'</textarea>','<button class="bp" data-a="cp">Copiar backup</button>')};
A.cp=function(){var t=$("bt"),ok=false,bad=function(){toast("Não consegui copiar. Segure o texto para copiar.")};t.focus();t.select();try{t.setSelectionRange(0,1e9)}catch(e){}try{ok=document.execCommand("copy")}catch(e){}
if(ok)return toast("Copiado.");try{navigator.clipboard.writeText(t.value).then(function(){toast("Copiado.")},bad)}catch(e){bad()}};
A.sn=function(){Share.share({text:$("bt").value}).catch(function(){})};
A.wk=function(){if(!DB.prods.length)return toast("Cadastre produtos primeiro.");wa("*Catálogo*\n"+DB.prods.map(function(p){return"• "+p.n+" — "+brl(p.pr)+(p.st<1?" (esgotado)":"")}).join("\n"))};
A.rs=function(){P("Restaurar backup","",'<p class="m">Cole o texto do backup. Isso substitui todos os dados atuais.</p><textarea id="bt" rows="10"></textarea>','<button class="bp" data-a="rs2">Restaurar</button>')};
A.rs2=function(){var d;try{d=JSON.parse($("bt").value);if(!d.prods||!d.ord)throw 0}catch(e){return toast("Backup inválido.")}
if(!confirm("Substituir todos os dados atuais?"))return;var ops=[],k=0;
["prods","cust","ord","cash"].forEach(function(n){var keep={};(d[n]||[]).forEach(function(x){var r=Object.assign({},x),id=String(n=="cash"&&x.oid?cashId(x.oid):x.id);delete r.id;
if(n=="prods")r.st=Math.max(0,r.st||0);if(n=="cash"){r.ts=r.ts||Number(x.id)||uid();if(x.oid)r.oid=String(x.oid)}
Object.keys(r).forEach(function(q){if(r[q]===undefined)delete r[q]});keep[id]=1;ops.push([1,n,id,r])});
DB[n].forEach(function(x){if(!keep[x.id])ops.push([0,n,x.id])})});
(function nx(){if(k>=ops.length){toast("Backup restaurado.");X();R();return}var b=FS.writeBatch(fdb);ops.slice(k,k+400).forEach(function(o){o[0]?b.set(dref(o[1],o[2]),o[3]):b.delete(dref(o[1],o[2]))});k+=400;toast("Restaurando…");b.commit().then(nx).catch(fail)})()};

document.addEventListener("click",function(e){var t=e.target.closest("[data-a]");if(t&&A[t.dataset.a])A[t.dataset.a](t.dataset.i)});
document.addEventListener("change",function(e){var t=e.target;if(t.dataset&&t.dataset.c)A[t.dataset.c](t.dataset.i,t.value);else if(t.dataset&&t.dataset.ph){PHload(t);t.value=""}});
document.addEventListener("input",function(e){var t=e.target;if(t.id=="f_d")ri();else if(t.dataset&&t.dataset.q){Q=t.value;$("lst").innerHTML=L[tab]()}});
if(Capacitor.isNativePlatform())App.addListener("backButton",function(){if(!$("sh").hidden)A.x2();else if(!$("md").hidden)X();else if(me&&tab!="home")A.tab("home");else App.exitApp()});
window.addEventListener("online",function(){if(me&&ready())R()});window.addEventListener("offline",function(){if(me&&ready())R()});
load();
if(String(firebaseConfig.apiKey).indexOf("COLE")==0)$("app").innerHTML='<div class="lg"><h1>Admin Loja</h1><p class="m">Falta configurar o Firebase. Edite src/firebase-config.js com as chaves do seu projeto.</p></div>';
else{$("app").innerHTML='<p class="m" style="text-align:center;padding-top:40vh">Carregando…</p>';
AU.onAuthStateChanged(auth,function(u){if(BUSY)return;if(!u){unsub();me=null;R();return}enter(u)})}

