# Site da Anelê — Verduras e legumes

Site de pedidos para o consumidor final. Lê o catálogo publicado pelo app e grava os pedidos no mesmo Firebase.

## Como colocar no ar (Netlify, grátis)
1. Crie uma conta em app.netlify.com (pode entrar com o Google).
2. Abra **app.netlify.com/drop** e envie o arquivo `anele-site.zip` (ou a pasta descompactada).
3. Em segundos o Netlify mostra um endereço (ex.: `algo-123.netlify.app`). Abra e confira.
4. Opcional: em **Site configuration > Change site name** troque por algo como `anele`.
5. No app: Configurações > Loja online > cole o endereço em "Endereço do site" > Salvar.

## Antes de abrir para clientes
- No app, publique as regras novas do Firebase (arquivo `firestore.rules` do app).
- Em Loja online, toque em **Publicar catálogo agora** e depois mude a Loja para **Aberta**.

## Como funciona
- O cliente monta o pedido, informa nome, WhatsApp, endereço e dia de entrega.
- O pedido é gravado no Firebase (aba **Site** do app) e o WhatsApp 5516988239933 abre com o resumo e um código (W-XXXXX).
- Você aprova no app: só então o estoque baixa e o pedido vai para a Separação.
- Preço enviado pelo site é ignorado: o app confere com os preços do dia.
- Taxa de entrega: combinada pelo WhatsApp e lançada em "Acréscimos" ao aprovar.
